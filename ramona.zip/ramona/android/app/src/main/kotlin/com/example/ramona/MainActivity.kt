package com.example.ramona

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
